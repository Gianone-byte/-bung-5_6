<section class="hero">
  <div class="container py-5">
    <div class="row align-items-center gy-5">
      <div class="col-lg-7">
        <span class="badge rounded-pill text-bg-primary text-uppercase mb-3">Welcome to</span>
        <h1 class="hero-heading">ScreenStack</h1>
        <p class="hero-subtitle">
          Your tracker and search engine for movies and TV shows. Discover new favorites, curate watchlists, and
          explore cinematic universes crafted by cutting-edge AI tools.
        </p>
        <div class="call-to-action d-flex flex-wrap gap-3">
          <a class="btn btn-primary btn-lg px-4" href="/movies">Browse the Watchlist</a>
          <a class="btn btn-outline-light btn-lg px-4" href="https://kit.svelte.dev" target="_blank" rel="noreferrer">
            Learn more about SvelteKit
          </a>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="position-relative">
          <div class="ratio ratio-3x4 rounded-4 overflow-hidden shadow-lg">
            <img src="/images/stellar-frontier.svg" alt="Collage of futuristic movie posters" class="w-100 h-100 object-fit-cover" />
          </div>
          <div class="position-absolute top-0 start-0 translate-middle bg-primary text-white fw-semibold px-3 py-2 rounded-pill">
            10 curated picks
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
